from setuptools import setup, find_packages

setup(
    name='optimal-placement-problem-on-the-plane',
    version='0.2',
    packages=find_packages(),
    url='',
    license='',
    author='AMukhtarov',
    author_email='mukhtarov.amir.matfiles@gmail.com',
    description=''
)
